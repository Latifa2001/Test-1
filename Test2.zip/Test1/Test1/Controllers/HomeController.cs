using Microsoft.AspNetCore.Mvc;
using Test1.Models;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Diagnostics;

namespace Test1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public HomeController(ILogger<HomeController> logger, IWebHostEnvironment webHostEnvironment)
        {
            _logger = logger;
            _webHostEnvironment = webHostEnvironment;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> GenerateWordFile(ShiftInfo model)
        {
            int j = 0;
            if (ModelState.IsValid)
            {
                var fileName = model.Date.Day.ToString() + model.Date.Month.ToString() + model.Date.Year.ToString() + "_" + model.ShiftType + "_Shift_Handover.docx";
                //var filePath = @"C:\Users\latif\Downloads\Test1.docx";
                var wwwRootPath = _webHostEnvironment.WebRootPath;

                // Combine it with the relative path to your doc file
                var filePath = Path.Combine(wwwRootPath, "Test1.docx");
                var memoryStream = new MemoryStream();

                // Copy template to memory stream
                using (var templateStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                {
                    await templateStream.CopyToAsync(memoryStream);
                }
                memoryStream.Position = 0;

                using (var wordDocument = WordprocessingDocument.Open(memoryStream, true))
                {
                    var mainPart = wordDocument.MainDocumentPart;
                    var body = mainPart.Document.Body;

                    // Extract all tables in the document, considering that each page starts with a table
                    var tables = body.Descendants<Table>().ToList();

                    // Make sure the number of tables is at least the number of pages we expect
                    if (tables.Count >= 7)
                    {
                        for (int tableNumber = 0; tableNumber < 26;)
                        {
                            var table = tables[tableNumber];
                            tableNumber = tableNumber + 4;
                            var rows = table.Elements<TableRow>().ToList();

                            if (rows.Count < 8)
                                continue; // Skip if the table does not have enough rows

                            // Fill first three member names in row 1, columns 2, 3, 4
                            for (int i = 0; i < 3; i++)
                            {
                                if (i < model.MemberNames.Length)
                                {
                                    var cell1 = rows[0].Elements<TableCell>().ElementAtOrDefault(i + 1);
                                    if (cell1 != null)
                                    {
                                        cell1.RemoveAllChildren<Paragraph>();
                                        cell1.Append(new Paragraph(new Run(new Text(model.MemberNames[i]))));
                                    }
                                }
                            }

                            // Fill last three member names in row 2, columns 2, 3, 4
                            for (int i = 0; i < 3; i++)
                            {
                                int memberIndex = model.MemberNames.Length - 3 + i;
                                if (memberIndex >= 0 && memberIndex < model.MemberNames.Length)
                                {
                                    var cell2 = rows[1].Elements<TableCell>().ElementAtOrDefault(i + 1);
                                    if (cell2 != null)
                                    {
                                        cell2.RemoveAllChildren<Paragraph>();
                                        cell2.Append(new Paragraph(new Run(new Text(model.MemberNames[memberIndex]))));
                                    }
                                }
                            }

                            // Fill combined member names in row 7, column 2
                            var combinedMemberNames = string.Join(", ", model.MemberNames.Where(n => !string.IsNullOrEmpty(n)));
                            var combinedCell = rows[6].Elements<TableCell>().ElementAtOrDefault(1);
                            if (combinedCell != null)
                            {
                                combinedCell.RemoveAllChildren<Paragraph>();
                                combinedCell.Append(new Paragraph(new Run(new Text(combinedMemberNames))));
                            }

                            // Fill date in row 3, column 2
                            var dateCell = rows[2].Elements<TableCell>().ElementAtOrDefault(1);
                            if (dateCell != null)
                            {
                                dateCell.RemoveAllChildren<Paragraph>();
                                dateCell.Append(new Paragraph(new Run(new Text(model.Date.ToShortDateString()))));
                            }

                            // Fill shift type in row 3, column 4
                            var shiftTypeCell = rows[2].Elements<TableCell>().ElementAtOrDefault(3);
                            if (shiftTypeCell != null)
                            {
                                shiftTypeCell.RemoveAllChildren<Paragraph>();
                                shiftTypeCell.Append(new Paragraph(new Run(new Text(model.ShiftType))));
                            }

                            // Fill handover writer name in row 8, column 2
                            var handoverWriterCell = rows[7].Elements<TableCell>().ElementAtOrDefault(1);
                            if (handoverWriterCell != null)
                            {
                                handoverWriterCell.RemoveAllChildren<Paragraph>();
                                handoverWriterCell.Append(new Paragraph(new Run(new Text(model.HandoverWriterName))));
                            }

                            // Fill T counts of raised alerts in row 5, column 2
                            if (j < model.RaisedAlertsCount.Length)
                            {
                                var raisedAlertsCell = rows[4].Elements<TableCell>().ElementAtOrDefault(1);
                                if (raisedAlertsCell != null)
                                {
                                    raisedAlertsCell.RemoveAllChildren<Paragraph>();
                                    raisedAlertsCell.Append(new Paragraph(new Run(new Text(model.RaisedAlertsCount[j].ToString()))));
                                    j++;
                                }
                            }
                        }
                    }

                    // Save changes
                    mainPart.Document.Save();
                }

                memoryStream.Position = 0;
                return File(memoryStream.ToArray(), "application/vnd.openxmlformats-officedocument.wordprocessingml.document", fileName);
            }

            // If the model state is not valid, return to the form with validation errors
            return View("Index", model);
        }
    }
}
