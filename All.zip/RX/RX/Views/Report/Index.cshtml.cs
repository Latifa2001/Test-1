using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RX.Views.Report
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
