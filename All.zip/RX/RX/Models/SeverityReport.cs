﻿namespace RX.Models
{
    public class SeverityReport
    {
        public int HighSeverityCount { get; set; }
        public int MediumSeverityCount { get; set; }
        public int LowSeverityCount { get; set; }
        public int InformationalSeverityCount { get; set; }
        public int ClosedStatusCount { get; set; }
        public int ActiveStatusCount { get; set; }
        public int TotalRows { get; set; }
        public List<string> HighSeverityTitles { get; set; } = new List<string>();
        public Dictionary<string, int> ClassificationCounts { get; set; } = new Dictionary<string, int>();
        public Dictionary<string, HashSet<string>> ClassificationSeverities { get; set; } = new Dictionary<string, HashSet<string>>();
        public Dictionary<string, string> HighSeverityRootCauses { get; set; } = new Dictionary<string, string>(); // New property
        public DateTime ReportDate { get; set; }
    }


}
