﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Test1.Models
{
    public class ShiftInfo
    {
        public string[] MemberNames { get; set; } = new string[6]; // Up to 6 member names
        public int[] RaisedAlertsCount { get; set; } = new int[7]; // Up to 7 counts
        public DateTime Date { get; set; }
        public string ShiftType { get; set; }
        public string HandoverWriterName { get; set; }
    }
}

